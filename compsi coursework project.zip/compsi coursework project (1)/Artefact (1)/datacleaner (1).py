import pandas as pd
import plotly.express as px
from flask import Flask, render_template
import numpy as np

app = Flask(__name__)

# Open raw file and clean it
df = pd.read_csv('drivingtestsdublinraw.csv')  # reads raw csv file
df = df.replace({'%' : ''}, regex=True)  # removes % symbols in pass rate column

# Change the values from strings to floats for data analysis
df['PassRate'] = df['PassRate'].astype(float) 
for column in df.columns:
    df[column] = pd.to_numeric(df[column], errors='ignore')
    
df = df.drop('County', axis=1)  # removes column for county

# Save as new clean file
cleandf = 'drivingtestsdublinclean.csv'
df.to_csv(cleandf, index=False)

non_numeric = ['Month']  # Columns to ignore
stats = {}

@app.route("/")
def home():
    global stats
    for col in df.columns:  # loop to go through each column
        if col not in non_numeric:  # skips unnecessary column
            stats_data = df[col]
            
            stats[col] = {
                'Mean': stats_data.mean(),
                'Median': stats_data.median(),
                'Mode': stats_data.mode().iloc[0] if not stats_data.mode().empty else np.nan,  # gets mode 
                'Range': stats_data.max() - stats_data.min()  # gets range of all columns
            }

    # Create a line graph of Applications over months
    fig = px.line(df, x='Month', y='ApplicationsRecieved', title="Applications per Month")
    
    # Convert the graph data to a JSON serializable format (convert NumPy arrays to lists)
    graph_data = fig.to_dict()
    
    # Convert any ndarray (numpy array) values to lists
    def convert_to_serializable(data):
        if isinstance(data, dict):
            return {k: convert_to_serializable(v) for k, v in data.items()}
        elif isinstance(data, list):
            return [convert_to_serializable(i) for i in data]
        elif isinstance(data, np.ndarray):
            return data.tolist()  # Convert numpy arrays to lists
        else:
            return data
    
    graph_data = convert_to_serializable(graph_data)

    # Print stats to console (for debugging purposes)
    for col, values in stats.items():
        print(f"{col} - Mean: {values['Mean']}, Median: {values['Median']}, Mode: {values['Mode']}, Range: {values['Range']}")
        print()

    # Pass the stats and the graph data to the template
    return render_template("index.html", stats=stats, graph_data=graph_data)

if __name__ == "__main__":
    from waitress import serve
    serve(app, host="0.0.0.0", port=8080)